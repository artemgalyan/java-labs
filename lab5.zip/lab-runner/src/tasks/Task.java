package tasks;

import java.util.Scanner;

import utils.ScannerPool;

public interface Task {
    void run();

    default void tryAgain() {
        System.out.println("Do you want to run task '" + this.getClass().getName() + "' again? yes/no");
        Scanner scanner = ScannerPool.get(System.in);
        var s = scanner.nextLine();
        System.out.println("Input was " + s);
        if (s.equals("yes"))
            run();
    }
}
