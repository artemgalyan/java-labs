package lab5;

public class Task {

}
