import lab3.ExpressionCounter;
import lab3.NumberDeleter;
import lab3.SuffixReplacer;
import lab4.BinaryTreeTester;
import lab4.ExpressionNormalizer;
import lab4.NumberFixer;
import lab5.CounterTasks;
import lab5.SeriesDemo;
import tasks.TaskPackage;
import tasks.TaskRunner;

public class Main {
    public static void main(String[] args) {
        var lab3 = new TaskPackage("lab-3")
                .addTask(ExpressionCounter.class)
                .addTask(SuffixReplacer.class)
                .addTask(NumberDeleter.class);
        var lab4 = new TaskPackage("lab-4")
                .addTask(BinaryTreeTester.class)
                .addTask(ExpressionNormalizer.class)
                .addTask(NumberFixer.class);
        var lab5 = new TaskPackage("lab-5")
                .addTask(SeriesDemo.class)
                .addTask(CounterTasks.class);
        var taskRunner = new TaskRunner();
        taskRunner.addPackage(lab3).addPackage(lab4).addPackage(lab5);
        taskRunner.run();
        System.out.println("Exiting the app..");
    }
}