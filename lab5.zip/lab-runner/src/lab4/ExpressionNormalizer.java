package lab4;

import java.util.Scanner;

import tasks.Task;
import utils.ScannerPool;

public class ExpressionNormalizer implements Task {

    @Override
    public void run() {
        Scanner scanner = ScannerPool.get(System.in);
        System.out.println("Input string: ");
        String input = scanner.nextLine();
        String normalized = normalizeString(input);
        System.out.println("Result is: " + normalized + ";");
        tryAgain();
    }

    public String normalizeString(String s) {
        return s
                .replaceAll("(?<= |\\A).(?= |\\Z)", "")
                .replaceAll(" +", " ")
                .replaceAll("\\A ", "")
                .replaceAll(" \\Z", "");
    }

}