package lab4;

import tasks.Task;
import utils.ScannerPool;

import java.util.Scanner;

public class NumberFixer implements Task {

    @Override
    public void run() {
        System.out.println("Input string: ");
        Scanner scanner = ScannerPool.get(System.in);
        String str = scanner.nextLine();
        System.out.println("Fixed string: " + normalizeNumbers(str));
        tryAgain();
    }

    public String normalizeNumbers(String expression) {
        return expression
                .replaceAll("(?<=\\s|\\A)(0*)(\\d+)(\\.\\d+)?(?=\\s|\\Z)", "$2$3");
    }
}
