package lab3;

import tasks.Task;
import utils.ConsoleUtils;

public class NumberDeleter implements Task {
    @Override
    public void run() {
        String str = ConsoleUtils.inputString("Input string: ");
        String result = str.replaceAll("((?<=[ ,.])|(?=\\A))(\\d+)((?=\\z)|(?=[ ,.]))", "");
        System.out.println("Result is: " + result);
        tryAgain();
    }

}
